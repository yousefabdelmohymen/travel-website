-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2024 at 09:32 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `travelll`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `name` varchar(55) DEFAULT NULL,
  `cus_id` int(11) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `ssn` int(11) NOT NULL,
  `bdate` date DEFAULT NULL,
  `phone` varchar(55) DEFAULT NULL,
  `email` varchar(55) DEFAULT NULL,
  `address` varchar(55) DEFAULT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`name`, `cus_id`, `year`, `ssn`, `bdate`, `phone`, `email`, `address`, `password`) VALUES
('kareem', 4, NULL, 52525282, '2024-04-23', '929829028972', 'kareem.helmii@gmail.com', 'ffsfsf', '12'),
('Omar', 6, NULL, 123456789, '2024-05-28', '01281875949', 'omar@gmail.com', 'alexandria', '1'),
('mark', 7, NULL, 12, '2024-05-31', '01281875934', 'mark@gmail.com', 'cairo', '1'),
('joe', 8, NULL, 14, '2024-05-28', '012818756655656', 'joe@gmail.com', 'Giza', '2');

-- --------------------------------------------------------

--
-- Table structure for table `office`
--

CREATE TABLE `office` (
  `offi_id` int(11) NOT NULL,
  `travel_id` int(11) DEFAULT NULL,
  `phone` varchar(55) DEFAULT NULL,
  `location` varchar(55) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `office`
--

INSERT INTO `office` (`offi_id`, `travel_id`, `phone`, `location`) VALUES
(1, 1, '09876', 'Gleem'),
(2, 2, '3546576890', 'london'),
(3, 3, '012345678', 'alex'),
(4, 4, '021354657687', 'alex'),
(5, 5, '222', 'giza'),
(6, 6, '123456789', 'New York'),
(7, 7, '987654321', 'Los Angeles'),
(8, 8, '456789012', 'Chicago'),
(9, 9, '654321789', 'Houston'),
(10, 10, '789012345', 'Phoenix'),
(11, 11, '012345678', 'Philadelphia'),
(12, 12, '345678901', 'San Antonio'),
(13, 13, '678901234', 'San Diego'),
(14, 14, '901234567', 'Dallas'),
(15, 15, '234567890', 'San Jose'),
(16, 16, '567890123', 'Austin'),
(17, 17, '890123456', 'Jacksonville'),
(18, 18, '345678901', 'Fort Worth'),
(19, 19, '678901234', 'Columbus'),
(20, 20, '901234567', 'Charlotte'),
(21, 21, '234567890', 'Indianapolis'),
(22, 22, '567890123', 'San Francisco'),
(23, 23, '890123456', 'Seattle'),
(24, 24, '345678901', 'Denver'),
(25, 25, '678901234', 'Washington'),
(26, 26, '901234567', 'Boston'),
(27, 27, '234567890', 'El Paso'),
(28, 28, '567890123', 'Detroit'),
(29, 29, '890123456', 'Nashville'),
(30, 30, '123456789', 'Portland'),
(31, 31, '987654321', 'Memphis'),
(32, 32, '456789012', 'Oklahoma City'),
(33, 33, '654321789', 'Las Vegas'),
(34, 34, '789012345', 'Louisville'),
(35, 35, '012345678', 'Baltimore'),
(36, 36, '345678901', 'Milwaukee'),
(37, 37, '678901234', 'Albuquerque'),
(38, 38, '901234567', 'Tucson'),
(39, 39, '234567890', 'Fresno'),
(40, 40, '567890123', 'Sacramento'),
(41, 41, '890123456', 'Mesa'),
(42, 42, '345678901', 'Atlanta'),
(43, 43, '678901234', 'Kansas City'),
(44, 44, '901234567', 'Colorado Springs'),
(45, 45, '234567890', 'Miami'),
(46, 46, '567890123', 'Raleigh'),
(47, 47, '890123456', 'Omaha'),
(48, 48, '345678901', 'Long Beach'),
(49, 49, '678901234', 'Virginia Beach'),
(50, 50, '901234567', 'Oakland'),
(51, 51, '234567890', 'Minneapolis'),
(52, 52, '567890123', 'Tulsa'),
(53, 53, '890123456', 'Arlington'),
(54, 54, '345678901', 'Tampa'),
(55, 55, '678901234', 'New Orleans'),
(56, 56, '901234567', 'Wichita'),
(57, 57, '234567890', 'Cleveland'),
(58, 58, '567890123', 'Bakersfield'),
(59, 59, '890123456', 'Aurora'),
(60, 60, '123456789', 'Anaheim'),
(61, 61, '987654321', 'Honolulu'),
(62, 62, '456789012', 'Santa Ana'),
(63, 63, '654321789', 'Corpus Christi'),
(64, 64, '789012345', 'Riverside'),
(65, 65, '012345678', 'Lexington'),
(66, 66, '345678901', 'St. Louis'),
(67, 67, '678901234', 'Stockton'),
(68, 68, '901234567', 'Pittsburgh'),
(69, 69, '234567890', 'Saint Paul'),
(70, 70, '567890123', 'Cincinnati'),
(71, 71, '890123456', 'Anchorage'),
(72, 72, '345678901', 'Henderson'),
(73, 73, '678901234', 'Greensboro'),
(74, 74, '901234567', 'Plano'),
(75, 75, '234567890', 'Newark'),
(76, 76, '567890123', 'Lincoln'),
(77, 77, '890123456', 'Orlando'),
(78, 78, '345678901', 'Chula Vista'),
(79, 79, '678901234', 'Buffalo'),
(80, 80, '901234567', 'Fort Wayne'),
(81, 81, '234567890', 'Jersey City'),
(82, 82, '567890123', 'Chandler'),
(83, 83, '890123456', 'St. Petersburg'),
(84, 84, '345678901', 'Durham'),
(85, 85, '678901234', 'Madison'),
(86, 86, '901234567', 'Lubbock'),
(87, 87, '234567890', 'Irvine'),
(88, 88, '567890123', 'Winston-Salem'),
(89, 89, '890123456', 'Glendale'),
(90, 90, '345678901', 'Garland'),
(91, 91, '678901234', 'Hialeah'),
(92, 92, '901234567', 'Reno'),
(93, 93, '234567890', 'Baton Rouge'),
(94, 94, '567890123', 'Irvine'),
(95, 95, '890123456', 'Chesapeake'),
(96, 96, '345678901', 'Irving'),
(97, 97, '678901234', 'Scottsdale'),
(98, 98, '901234567', 'North Las Vegas'),
(99, 99, '234567890', 'Fremont'),
(100, 100, '567890123', 'Gilbert');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `pay_date` date DEFAULT NULL,
  `amount` decimal(10,0) DEFAULT NULL,
  `res_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `pay_date`, `amount`, `res_id`) VALUES
(24, '2024-05-11', 183000, 24),
(25, '2024-05-11', 438000, 25),
(26, '2024-05-11', 420900, 26);

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `res_id` int(11) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `travel_id` int(11) DEFAULT NULL,
  `cus_id` int(11) DEFAULT NULL,
  `offi_id` int(11) DEFAULT NULL,
  `amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`res_id`, `start_date`, `end_date`, `travel_id`, `cus_id`, `offi_id`, `amount`) VALUES
(24, '2020-01-01', '2021-01-01', 1, 6, 1, 183000),
(25, '2022-01-01', '2024-01-01', 2, 6, 2, 438000),
(26, '2020-01-01', '2021-01-01', 26, 4, 26, 420900);

-- --------------------------------------------------------

--
-- Table structure for table `travels`
--

CREATE TABLE `travels` (
  `travel_id` int(11) NOT NULL,
  `color` varchar(55) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `travell_id` varchar(50) NOT NULL,
  `destination` varchar(55) DEFAULT NULL,
  `status` varchar(55) DEFAULT 'available',
  `name` varchar(400) NOT NULL,
  `price` int(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `travels`
--

INSERT INTO `travels` (`travel_id`, `color`, `year`, `travell_id`, `destination`, `status`, `name`, `price`) VALUES
(1, 'gold', 2020, '1', 'cairo', 'unavailable', 'Cairo', 500),
(2, 'silver', 2021, '2', 'alexandria', 'unavailable', 'alexandria', 600),
(3, 'gold', 2022, '3', 'giza', 'available', 'giza', 200),
(4, 'gold', 2023, '4', 'aswan', 'available', 'Aswan', 900),
(5, 'silver', 2024, '5', 'Luxor', 'available', 'Luxor Tour', 700),
(6, 'gold', 2024, '6', 'Sharm El Sheikh', 'available', 'Sharm El Sheikh Retreat', 1200),
(7, 'gold', 2024, '7', 'Hurghada', 'available', 'Hurghada Escape', 800),
(8, 'silver', 2024, '8', 'Dahab', 'available', 'Dahab Adventure', 900),
(9, 'gold', 2024, '9', 'Marsa Alam', 'available', 'Marsa Alam Expedition', 1000),
(10, 'silver', 2024, '10', 'Taba', 'available', 'Taba Getaway', 600),
(11, 'gold', 2024, '11', 'Sahl Hasheesh', 'available', 'Sahl Hasheesh Trip', 1500),
(12, 'gold', 2024, '12', 'El Gouna', 'available', 'El Gouna Experience', 1100),
(13, 'silver', 2024, '13', 'Nuweiba', 'available', 'Nuweiba Retreat', 750),
(14, 'gold', 2024, '14', 'Ras Sudr', 'available', 'Ras Sudr Adventure', 950),
(15, 'silver', 2024, '15', 'Makadi Bay', 'available', 'Makadi Bay Escape', 650),
(16, 'gold', 2024, '16', 'Marsa Matruh', 'available', 'Marsa Matruh Expedition', 1300),
(17, 'gold', 2024, '17', 'Soma Bay', 'available', 'Soma Bay Trip', 1400),
(18, 'silver', 2024, '18', 'Ain Sokhna', 'available', 'Ain Sokhna Getaway', 850),
(19, 'gold', 2024, '19', 'Port Said', 'available', 'Port Said Experience', 1050),
(20, 'silver', 2024, '20', 'Ras El Bar', 'available', 'Ras El Bar Retreat', 720),
(21, 'gold', 2024, '21', 'Dahshur', 'available', 'Dahshur Adventure', 960),
(22, 'silver', 2024, '22', 'El Alamein', 'available', 'El Alamein Escape', 680),
(23, 'gold', 2024, '23', 'Suez', 'available', 'Suez Expedition', 1250),
(24, 'gold', 2024, '24', 'Siwa Oasis', 'available', 'Siwa Oasis Trip', 1550),
(25, 'silver', 2024, '25', 'Saint Catherine', 'available', 'Saint Catherine Getaway', 620),
(26, 'gold', 2024, '26', 'Wadi Natrun', 'unavailable', 'Wadi Natrun Experience', 1150),
(27, 'silver', 2024, '27', 'Mersa Matruh', 'available', 'Mersa Matruh Retreat', 770),
(28, 'gold', 2024, '28', 'Port Fuad', 'available', 'Port Fuad Adventure', 980),
(29, 'gold', 2024, '29', 'El Tor', 'available', 'El Tor Expedition', 1350),
(30, 'silver', 2024, '30', 'Damanhur', 'available', 'Damanhur Trip', 690);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`cus_id`,`ssn`);

--
-- Indexes for table `office`
--
ALTER TABLE `office`
  ADD PRIMARY KEY (`offi_id`),
  ADD UNIQUE KEY `travel_id` (`travel_id`),
  ADD KEY `car_id` (`travel_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `res_id` (`res_id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`res_id`),
  ADD KEY `car_id` (`travel_id`),
  ADD KEY `cus_id` (`cus_id`),
  ADD KEY `offi_id` (`offi_id`);

--
-- Indexes for table `travels`
--
ALTER TABLE `travels`
  ADD PRIMARY KEY (`travel_id`),
  ADD UNIQUE KEY `travell_id` (`travell_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `cus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `office`
--
ALTER TABLE `office`
  MODIFY `offi_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `res_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `travels`
--
ALTER TABLE `travels`
  MODIFY `travel_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`res_id`) REFERENCES `reservation` (`res_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
