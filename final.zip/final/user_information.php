<?php
session_start();

include("config.php");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$userInfo = getUserInfo($_SESSION["user_id"], $conn);
$reservedtravels = getRentedCars($_SESSION["user_id"], $conn);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Information</title>
    <link rel="stylesheet" href="styles.css">
    <style>
@charset "utf-8";
/* CSS Document */
        body, html {
         height: 100%;
        }
 
       body {
         background: rgb(0, 0, 0);
         background: -moz-radial-gradient(center, ellipse cover, rgba(0, 0, 0, 1) 0%, rgba(0, 0, 0, 1) 100%);
         background: -webkit-gradient(radial, center center, 0px, center center, 100%, color-stop(0%, rgba(0, 0, 0, 1)), color-stop(100%, rgba(0, 0, 0, 1)));
         background: -webkit-radial-gradient(center, ellipse cover, rgba(0, 0, 0, 1) 0%, rgba(0, 0, 0, 1) 100%);
         background: -o-radial-gradient(center, ellipse cover, rgba(0, 0, 0, 1) 0%, rgba(0, 0, 0, 1) 100%);
         background: -ms-radial-gradient(center, ellipse cover, rgba(0, 0, 0, 1) 0%, rgba(0, 0, 0, 1) 100%);
         background: radial-gradient(ellipse at center, rgba(0, 0, 0, 1) 0%, rgba(0, 0, 0, 1) 100%);
         filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#000000', endColorstr='#000000', GradientType=1);
         padding: 0;
         margin: 0;
        }


        .container {
            text-align: center;
            margin-top: 20px;
            color:red;
        }

        .user-info {
            background-color: #f4f4f4;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            width: 80%;
            max-width: 600px;
            margin: 0 auto;
        }

        .rented-travels table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        .rented-travels th, .rented-cars td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        .rented-travels th {
            background-color: #4caf50;
            color: white;
        }

        .btn-container {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 10px;
        }

        .btn-container button {
            padding: 8px 16px;
            cursor: pointer;
        }


        .btn-container button.change-dates {
            background-color: #3399ff;
            color: white;
        }
		/* Styling for logout button */
        .logout-btn {
            color: blue;
            text-decoration: none;
        }

        .logout-btn:hover {
            color: blue;
        }

        .container {
            max-width: 50%;
            margin: 10px auto;
            text-align: center;
            background-color: rgba(0, 0, 0, 0.4); /* Use rgba to add some transparency to the background */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            position: relative;
        }

        h1 {
            color: #fffcfc;
        }

        form {
            margin-top: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #ffffff;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #dc2b0c;
            color: #fff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #9f0000;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>User Information</h1>

        <!-- User Details -->
        <div class="user-info">
            <h2>User Details</h2>
            <p><strong>Name:</strong> <?php echo $userInfo['name']; ?></p>
            <p><strong>Email:</strong> <?php echo $userInfo['email']; ?></p>
            <p><strong>Address:</strong> <?php echo $userInfo['address']; ?></p>
        </div>

        <!-- Reserved tickets Information -->
        <div class="rented-travels">
            <h2>Reserved Tickets</h2>
            <?php if (!empty($reservedtravels)) : ?>
                <table>
                    <thead>
                        <tr>
                            <th>Travel Name</th>
                            <th>Travel Destination</th>
                            <th>Travel ID</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Total Price</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reservedtravels as $travel) : ?>
                            <tr>
                                <td><?php echo $travel['travel_name']; ?></td>
                                <td><?php echo $travel['travel_destination']; ?></td>
                                <td><?php echo $travel['travell_id']; ?></td>
                                <td><?php echo $travel['start_date']; ?></td>
                                <td><?php echo $travel['end_date']; ?></td>
                                <td><?php echo $travel['amount']; ?></td>
                                <td class="btn-container">
                                    <button class="change-dates" onclick="changeDates(<?php echo $travel['res_id']; ?>)">Change Dates</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else : ?>
                <p>No reserved Tickets information available.</p>
            <?php endif; ?>
        </div>

        <a href="logout.php" class="logout-btn">Logout</a> <br>
    </div>
    </div>
    <div class="container">
        <h1>Want to Reset Your Password?</h1>
        <form action="change_password.php" method="post">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required><br>
            <input type="submit" value="Reset Password">
        </form>
    
    </div>
    <script>
        function changeDates(reservationId) {
            var newStartDate = prompt("Enter new start date:");
            var newEndDate = prompt("Enter new end date:");

            if (!newStartDate || !newEndDate) {
                alert("Please enter valid dates.");
                return;
            }

            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        var response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            alert("Dates updated successfully!");
                            location.reload();
                        } else {
                            alert("Failed to update dates. Please try again.");
                        }
                    } else {
                        alert("Error updating dates. Please try again later.");
                    }
                }
            };

            xhr.open("POST", "update_dates.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.send("reservationId=" + reservationId + "&startDate=" + newStartDate + "&endDate=" + newEndDate);
        }
        
    </script>
</body>
</html>

<?php
function getUserInfo($userId, $conn) {
    $userInfoQuery = "SELECT * FROM customers WHERE cus_id = ?";
    $stmtUserInfo = $conn->prepare($userInfoQuery);
    $stmtUserInfo->bind_param("i", $userId);
    $stmtUserInfo->execute();
    $resultUserInfo = $stmtUserInfo->get_result();

    return $resultUserInfo->fetch_assoc();
}

function getRentedCars($userId, $conn) {
    $rentedCarsQuery = "SELECT r.*, c.name AS travel_name, c.destination AS travel_destination, c.travell_id, p.amount
                        FROM reservation r
                        JOIN travels c ON r.travel_id = c.travel_id
                        LEFT JOIN payment p ON r.res_id = p.res_id
                        WHERE r.cus_id = ?";
    $stmtRentedCars = $conn->prepare($rentedCarsQuery);
    $stmtRentedCars->bind_param("i", $userId);
    $stmtRentedCars->execute();
    $resultReservedtravels = $stmtRentedCars->get_result();

    $reservedtravels = [];
    while ($travel =  $resultReservedtravels->fetch_assoc()) {
        $reservedtravels[] = $travel;
    }

    return $reservedtravels;
}
?>
