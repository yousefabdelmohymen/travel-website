<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Redirect to login page if not logged in
    exit();
}

include("config.php");

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST["new_password"])) {
        $newPassword = $_POST["new_password"];
        $customerId = $_SESSION["user_id"];

        // Update the user's password in the database
        $updatePasswordQuery = "UPDATE customers SET password = ? WHERE cus_id = ?";
        $stmtUpdatePassword = $conn->prepare($updatePasswordQuery);
        $stmtUpdatePassword->bind_param("si", $newPassword, $customerId);

        if ($stmtUpdatePassword->execute()) {
            $passwordChanged = true;
        } else {
            $passwordChanged = false;
        }

        $stmtUpdatePassword->close();
    } else {
        // Handle case where new password field is not set
        echo "New password field is not set.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-image: url(images/window.jpg);
            background-size: cover; /* Resize the background image to fit within the container */
            background-repeat: no-repeat; /* Prevent the background image from repeating */
            background-position: center; /* Center the background */
            font-family: Arial, sans-serif;
            background-color: #D3D3D3 ;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            font-family: Arial, sans-serif;
        
        }

    </style>
</head>
<body>
    <div class="container mt-4">
        <h1><strong>Change Password</strong></h1>

        <?php if (isset($passwordChanged) && $passwordChanged): ?>
            <div class="alert alert-success" role="alert">
                Password changed successfully!
            </div>
        <?php endif; ?>

        <form action="" method="post">
            <div class="form-group">
                <label for="new_password">New Password:</label>
                <input type="password" class="form-control" id="new_password" name="new_password" required>
            </div>

            <button type="submit" class="btn btn-primary">Change Password</button>
        </form>

        <a href="user_information.php" class="btn btn-secondary mt-3">Back to User Information</a>
    </div>
</body>
</html>
