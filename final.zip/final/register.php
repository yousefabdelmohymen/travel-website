
<?php
include("config.php");



// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $ssn = $_POST["ssn"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $address = $_POST["address"];
    $bdate = $_POST["bdate"];
    $password = $_POST["password"]; 
    // Check if the SSN or email already exists
    $checkSql = "SELECT * FROM customers WHERE ssn = $ssn OR email = '$email'";
    $checkResult = $conn->query($checkSql);

    if ($checkResult->num_rows > 0) {
        echo "User with the provided SSN or email already exists.";
    } else {
        // Insert data into the customers table
        $sql = "INSERT INTO customers (name, ssn, bdate, phone, email, address, password) VALUES ('$name', $ssn, '$bdate', '$phone', '$email', '$address', '$password')";

        if ($conn->query($sql) === TRUE) {
            echo "Registration successful";
            return   header("Location: travels_catalog.php");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

// Close the database connection
$conn->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            max-width: 1300px;
    margin: auto;
    width: 100%;
    min-height: 640px;
    display: flex;
    align-items: center;


            font-family: 'Work Sans', sans-serif;
            height: 100vh;
            justify-content: center;
            padding: 0;
            background:url(images/nb.jpg) no-repeat;
            background-size: cover;
            background-position: center left;
            background-size: cover;
        }
        
        .navbar {
            position: absolute; /* Make navbar position absolute */
            top: 0; /* Align navbar to the top */
            left: 0; /* Align navbar to the left */
            background-color: rgb(196, 0, 0); /* Changed navbar color to red */
            overflow: hidden;
            width: 100%; /* Make navbar full width */
            padding: 0px 1px;
        }

        .navbar a {
            float: left;
            display: block;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 8px; /* Adjust padding here */
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }

        .navbar img {
            float: right; /* Float the logo to the right */
            height: 50px; /* Set the height of the logo */
            margin: 2px 5px; /* Add margin for spacing */
        }

        form {
            max-width: 100%;
    margin: 200px auto;
    text-align: center;
    background-color: rgba(0, 0, 0, 0.4); /* Use rgba to add some transparency to the background */
    padding: 2px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    position: absolute;
    top:-450px;
    right:180px;
        }

        h2 {
            text-align: center;
            color: white;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin: 10px 0 5px;
            color:white;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            text-decoration: none;
            background-color: rgb(196, 0, 0); /* Changed button color to red */
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .btn:hover {
            background-color: darkred; /* Darkened button color on hover */
        }
    </style>
</head>
<body>
<div class="navbar">
        <a href="index.html">Home</a>
        <a href="travels_catalog.php">Destinations</a>
        <a href="about.html">About</a>
        <a href="contact.html">Contact</a>
        <img src="images/logo2.png" alt="Travel Logo"> <!-- Insert your travel logo here -->
    </div>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <form action="register.php" method="post">
                    <h2>User Registration</h2>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="name">Name:</label>
                            <input type="text" class="form-control" name="name" required>
                        </div>

                        <div class="form-group col-md-6">
                            <label for="ssn">SSN:</label>
                            <input type="text" class="form-control" name="ssn" required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="email">Email:</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>

                        <div class="form-group col-md-6">
                            <label for="phone">Phone:</label>
                            <input type="text" class="form-control" name="phone" required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="address">Address:</label>
                            <input type="text" class="form-control" name="address" required>
                        </div>

                        <div class="form-group col-md-6">
                            <label for="bdate">Birth Date:</label>
                            <input type="date" class="form-control" name="bdate" required>
                        </div>
                    </div>

                    <!-- Password field -->
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" class="form-control" name="password" required>
                    </div>

                    <button type="submit" class="btn btn-success">Register</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Include Bootstrap JS (optional, for some components) -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>