<?php
session_start();

include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if it's the manager's credentials
    $managerEmail = "admin@gmail.com";
    $managerPassword = "admin123";

    if ($email == $managerEmail && $password == $managerPassword) {
        // Redirect to the admin panel
        header("Location: admin.php");
        exit();
    } else {
        // Check if the user exists in the database
        $checkUserQuery = "SELECT cus_id, name FROM customers WHERE email = ? AND password = ?";
        $stmt = $conn->prepare($checkUserQuery);

        if ($stmt === false) {
            die('Error preparing statement: ' . $conn->error);
        }

        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result === false) {
            die('Error executing statement: ' . $stmt->error);
        }

        if ($result->num_rows > 0) {
            // User found, store user details in session
            $user = $result->fetch_assoc();
            $_SESSION["user_id"] = $user["cus_id"];
            $_SESSION["user_name"] = $user["name"];

            // Redirect to the travels catalog
            header("Location: travels_catalog.php");
            exit();
        } else {
            // Incorrect email or password
            $error_message = "Incorrect email or password. Please try again.";
        }
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <title>Login</title>
   
     <style>
        body {
            max-width: 1300px;
            margin: auto;
            width: 100%;
            min-height: 640px;
            display: flex;
            align-items: center;
            font-family: 'Work Sans', sans-serif;
            height: 100vh;
            justify-content: center;
            padding: 0;
            background:url(images/nb.jpg) no-repeat;
            background-position: center left;
            background-size: cover;
            position: relative; /* Add position relative */
        }

        .navbar {
            position: absolute; /* Make navbar position absolute */
            top: 0; /* Align navbar to the top */
            left: 0; /* Align navbar to the left */
            background-color: rgb(196, 0, 0); /* Changed navbar color to red */
            overflow: hidden;
            width: 100%; /* Make navbar full width */
            padding: 0px 1px;
        }

        .navbar a {
            float: left;
            display: block;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 8px; /* Adjust padding here */
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }

        .navbar img {
            float: right; /* Float the logo to the right */
            height: 50px; /* Set the height of the logo */
            margin: 2px 5px; /* Add margin for spacing */
        }

        .custom-container {
            width: 80%;
            max-width: 600px; /* Adjust the max-width as needed */
        }

        form {
            max-width: 100%;
            margin: 100px auto;
            text-align: center;
            background-color: rgba(0, 0, 0, 0.4); /* Use rgba to add some transparency to the background */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            position: relative;
        }

        h1 {
            text-align: center;
            color:white;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin: 10px 0 5px;
            color: white;
        }

        input {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
            display: inline-block;
            vertical-align: middle;
        }

        .input-icon {
            font-size: 18px;
            margin-right: 10px;
        }

        input[type="submit"] {
            background-color: red; /* Change button background color to red */
            color: #fff;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: darkred; /* Darken button color on hover */
        }

        a {
            color: red;
            text-decoration: none;
            font-weight: bold;
            margin-top: 10px;
            display: inline-block;
        }

        a:hover {
            text-decoration: underline;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            text-decoration: none;
            background-color: rgb(196, 0, 0); /* Changed button color to red */
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .btn:hover {
            background-color: darkred; /* Darkened button color on hover */
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="index.html">Home</a>
        <a href="travels_catalog.php">Destinations</a>
        <a href="about.html">About</a>
        <img src="images/logo2.png" alt="Travel Logo"> <!-- Insert your travel logo here -->
    </div>
    <div class="custom-container">
        <form action="login.php" method="post">
            <h1>Login</h1>

            <div class="form-group">
                <label for="email">
                    <i class="fas fa-envelope input-icon"></i>Email:
                </label>
                <input type="email" class="form-control" name="email" placeholder="Enter your Email" required>
            </div>

            <div class="form-group">
                <label for="password">
                    <i class="fas fa-lock input-icon"></i>Password:
                </label>
                <input type="password" class="form-control" name="password" placeholder="Enter your Password" required>
            </div>

            <button type="submit" class="btn">Login</button>

            <p class="mt-3"><a href="register.php">Don't have an account? Register here</a></p>
            <p><a href="forgot_password.html">Forgot your password?</a></p>
        </form>
    </div>

    <!-- Include Bootstrap JS (optional, for some components) -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <!-- Include Font Awesome JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
</body>
</html>
