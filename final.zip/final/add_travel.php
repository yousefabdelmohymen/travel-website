<?php
session_start();

$dserver = "localhost";
$dusername = "root";
$dpassword = "";
$ddatabase = "travelll";

$message = ""; // Initialize the message variable

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize form data
    $travelName = isset($_POST["name"]) ? htmlspecialchars($_POST["name"]) : "";
    $ticketColour = isset($_POST["color"]) ? htmlspecialchars($_POST["color"]) : "";
    $travelYear = isset($_POST["year"]) ? htmlspecialchars($_POST["year"]) : "";
    $travellID = isset($_POST["travell_id"]) ? htmlspecialchars($_POST["travell_id"]) : "";
    $travelDestination = isset($_POST["destination"]) ? htmlspecialchars($_POST["destination"]) : "";
    $ticketPriceMonth = isset($_POST["price"]) ? htmlspecialchars($_POST["price"]) : "";
    $officeLocation = isset($_POST["office_location"]) ? htmlspecialchars($_POST["office_location"]) : "";
    $officePhone = isset($_POST["office_phone"]) ? htmlspecialchars($_POST["office_phone"]) : "";

    // Check if all required fields are filled
    if (empty($travelName) || empty($ticketColour) || empty($travelYear) || empty($travellID) || empty($travelDestination) || empty($ticketPriceMonth) || empty($officeLocation) || empty($officePhone)) {
        $message = "Please fill all required fields.";
    } else {
        // Create a connection
        $conn = new mysqli($dserver, $dusername, $dpassword, $ddatabase);

        // Check the connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        try {
            // Check if the travel with the same ID already exists
            $checkTravelQuery = "SELECT travell_id FROM travels WHERE travell_id = ?";
            $stmtCheck = $conn->prepare($checkTravelQuery);

            if (!$stmtCheck) {
                throw new Exception("Error preparing check statement: " . $conn->error);
            }

            $stmtCheck->bind_param("s", $travellID);
            $stmtCheck->execute();
            $stmtCheck->store_result();

            if ($stmtCheck->num_rows > 0) {
                $message = "Ticket with the same travel ID already exists!";
            } else {
                // Insert new travel data into the database
                $insertTravelQuery = "INSERT INTO travels (name, color, year, travell_id, destination, `status`, price) VALUES (?, ?, ?, ?, ?, 'available', ?)";
                $stmtTravel = $conn->prepare($insertTravelQuery);

                if (!$stmtTravel) {
                    throw new Exception("Error preparing travel statement: " . $conn->error);
                }

                $stmtTravel->bind_param("ssissd", $travelName, $ticketColour, $travelYear, $travellID, $travelDestination, $ticketPriceMonth);

                if ($stmtTravel->execute()) {
                    // Redirect the user to the success page
                    header("Location: travel_added.php");
                    exit();
                } else {
                    throw new Exception("Error adding ticket: " . $stmtTravel->error);
                }

                
            }

            // Close the check statement
            $stmtCheck->close();
        } catch (Exception $e) {
            $message = "Error: " . $e->getMessage();
        } finally {
            // Close the connection
            $conn->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Travel Form</title>
   <style>
        body {
        background-image: url(images/window.jpg);
        background-size: cover; /* Resize the background image to fit within the container */
        background-repeat: no-repeat; /* Prevent the background image from repeating */
        background-position: center; /* Center the background */
        font-family: Arial, sans-serif;
        background-color: red; /* Change to black */
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
    }

        form {
            background-color: #F5F5F5;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            width: 80%;
            max-width: 400px; /* Increased width for additional fields */
            height: 100%;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
        }
        input, select {
            width: calc(100% - 16px); /* Adjust width */
            padding: 6px; /* Adjusted padding */
            margin-bottom: 6px; /* Adjusted margin */
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .message {
            color: #ff0000;
            margin-bottom: 10px;
        }
    </style> 
</head>
<body>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

        <h2>Add a Ticket</h2>
    
        <label for="name">Travel Name:</label>
    <input type="text" id="name" name="name" required>

    <!--<label for="color">Ticket Color:</label>
    <input type="text" id="color" name="color" placeholder="choose from gold and silver" required> -->
    <label for="color">Ticket Color:</label>
    <select id="color" name="color" required>
        <option value="gold">Gold</option>
        <option value="silver">Silver</option>
    </select> 

    <label for="year">Travel Year:</label>
    <input type="text" id="year" name="year" required pattern="[0-9]{4}" title="Enter a valid year">

    <label for="travell_id">Travel ID:</label>
    <input type="text" id="travell_id" name="travell_id" required>

    <label for="destination">Destination:</label>
    <input type="text" id="destination" name="destination" required>

    <label for="price">Ticket Price:</label>
    <input type="text" id="price" name="price" required>

    <label for="office_location">Office Location:</label>
    <input type="text" id="office_location" name="office_location" required>

    <label for="office_phone">Office Phone:</label>
    <input type="text" id="office_phone" name="office_phone" required>

    <input type="submit" value="Add Ticket">
    <div class="message"><?php echo $message; ?></div>
</form>
</body>
</html>
