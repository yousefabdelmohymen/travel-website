<div class="navbar">
        <a href="index.html">Home</a>
        <a href="travels_catalog.php">Destinations</a>
        <a href="about.html">About</a>
        <img src="images/logo2.png" alt="Travel Logo"> <!-- Insert your travel logo here -->
    </div>
<style>
      .navbar {
            position: absolute; /* Make navbar position absolute */
            top: 0; /* Align navbar to the top */
            left: 0; /* Align navbar to the left */
            background-color: rgb(196, 0, 0); /* Changed navbar color to red */
            overflow: hidden;
            width: 100%; /* Make navbar full width */
            padding: 0px 1px;
        }

        .navbar a {
            float: left;
            display: block;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 8px; /* Adjust padding here */
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }

        .navbar img {
            float: right; /* Float the logo to the right */
            height: 50px; /* Set the height of the logo */
            margin: 2px 5px; /* Add margin for spacing */
        }

        .custom-container {
            width: 80%;
            max-width: 600px; /* Adjust the max-width as needed */
        }

        form {
            max-width: 100%;
            margin: 100px auto;
            text-align: center;
            background-color: rgba(0, 0, 0, 0.4); /* Use rgba to add some transparency to the background */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            position: relative;
        }

        h1 {
            text-align: center;
            color:white;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin: 10px 0 5px;
            color: white;
        }

        input {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
            display: inline-block;
            vertical-align: middle;
        }

        .input-icon {
            font-size: 18px;
            margin-right: 10px;
        }

        input[type="submit"] {
            background-color: red; /* Change button background color to red */
            color: #fff;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: darkred; /* Darken button color on hover */
        }

        a {
            color: red;
            text-decoration: none;
            font-weight: bold;
            margin-top: 10px;
            display: inline-block;
        }

        a:hover {
            text-decoration: underline;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            text-decoration: none;
            background-color: rgb(196, 0, 0); /* Changed button color to red */
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .btn:hover {
            background-color: darkred; /* Darkened button color on hover */
        }
</style>

<?php
session_start();

include("config.php");

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Define an array of searchable attributes
$searchAttributes = ['name', 'color', 'year', 'destination'];

// Process search form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $searchQuery = htmlspecialchars($_POST["search"]);
    $searchAttribute = $_POST["search_attribute"];

    // Validate the selected search attribute
    if (in_array($searchAttribute, $searchAttributes)) {
        // Use prepared statement to prevent SQL injection
        $stmt = $conn->prepare("SELECT c.*, o.location AS office_location, o.phone FROM travels c
                  LEFT JOIN office o ON c.travel_id = o.travel_id
                  WHERE $searchAttribute LIKE ?");
        $stmt->bind_param("s", $searchParam);
        $searchParam = "%$searchQuery%";
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();
    } else {
        // Invalid search attribute, fetch all travel data
        $result = $conn->query("SELECT c.*, o.location AS office_location, o.phone FROM travels c
                  LEFT JOIN office o ON c.travel_id = o.travel_id");
    }
} else {
    // Fetch all travel data from the database
    $result = $conn->query("SELECT c.*, o.location AS office_location, o.phone FROM travels c
              LEFT JOIN office o ON c.travel_id = o.travel_id");
}

// Check if there are travels in the database
if ($result === false) {
    die("Error executing query: " . $conn->error);
}

// Render HTML
renderCatalog($result);

// Close the connection
$conn->close();

function renderCatalog($result)
{
    if ($result->num_rows > 0) {
        ?>
        <!DOCTYPE html>
        <html lang='en'>
        <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1.0'>
            <title>Travels Catalog</title>
            <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>
            <style>
    body {
        background-color: #1a1a1a;
        color: #fff;
    }

    .container {
        margin-top: 20px;
    }

    .travel-container {
        display: flex;
        flex-wrap: wrap;
    }

    .travel {
        border: 1px solid #444;
        border-radius: 8px;
        padding: 10px;
        margin: 10px;
        width: 300px;
        color: #fff;
        background-color: #333;
    }

    .rented-status {
        background-color: #8a1f11;
    }

    .travel img {
        max-width: 100%;
        height: auto;
        border-radius: 8px;
    }

    .rent-button {
        background-color: #4caf50;
        color: #fff;
        padding: 8px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    .rent-button:hover {
        background-color: #45a049;
    }
</style>

            <script src='https://code.jquery.com/jquery-3.5.1.slim.min.js'></script>
            <script src='https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js'></script>
            <script src='https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.min.js'></script>
            <script src='rent.js' defer></script>
        </head>
        <body>
            <div class='container'>
                <h1 class='mt-4 mb-4'>Travels Catalog</h1>
                <form action='' method='post'>
                    <div class='form-group'>
                        <label for='search'>Search for travels:</label>
                        <input type='text' class='form-control' name='search' id='search' placeholder='Search for travels'>
                    </div>
                    <div class='form-group'>
                        <label for='search_attribute'>Search by:</label>
                        <select name='search_attribute' id='search_attribute'>
                            <option value='name'>Name</option>
                            <option value='color'>Color</option>
                            <option value='year'>Year</option>
                            <option value='destination'>Destination</option>
                        </select>
                    </div>
                    <button type='submit' class='btn btn-primary'>Search</button>
                </form>
                <div class='travel-container'>
        <?php

        // Output each travel
        while ($row = $result->fetch_assoc()) {
            $statusClass = ($row['status'] == 'unavailable') ? 'rented-status' : '';
            echo "<div class='travel $statusClass'>
                <p><strong>Name:</strong> " . htmlspecialchars($row['name']) . "</p>
                <p><strong>Color:</strong> " . htmlspecialchars($row['color']) . "</p> 
                <p><strong>Year:</strong> " . htmlspecialchars($row['year']) . "</p>
                <p><strong>Travel ID:</strong> " . htmlspecialchars($row['travel_id']) . "</p>
                <p><strong>Destination:</strong> " . htmlspecialchars($row['destination']) . "</p>
                <p><strong>Price per Month:</strong> $" . htmlspecialchars($row['price']) . "</p>
                <p><strong>Office Location:</strong> " . htmlspecialchars($row['office_location']) . "</p>
                <p><strong>Phone:</strong> " . htmlspecialchars($row['phone']) . "</p>
                <button class='rent-button btn btn-primary' onclick='rentCar(" . $row['travel_id'] . ", \"" . htmlspecialchars($row['name']) . "\", " . $row['price'] . ")'>Rent Travel</button>
            </div>";
        }

        ?>
                </div>
            </div>
            <!-- Add this button within the travel-container -->
            <a href='user_information.php' class='btn btn-info mt-2'>Your Information</a>
        </body>
        </html>
        <?php
    } else {
        echo "<h1>No travels available in the catalog.</h1>";
    }
}
?>
