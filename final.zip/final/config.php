<?php

$conn = mysqli_connect("localhost","root","","travelll") or die ("Could not connect");



?>