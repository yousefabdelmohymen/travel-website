<?php
session_start();

$dserver = "localhost";
$dusername = "root";
$dpassword = "";
$ddatabase = "travelll";

include("config.php");

$message = ""; // Initialize an empty variable to store the message

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];

    // Create a connection
    $conn = new mysqli($dserver, $dusername, $dpassword, $ddatabase);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if the email exists in the database
    $checkEmailQuery = "SELECT * FROM customers WHERE email = ?";
    $stmt = $conn->prepare($checkEmailQuery);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Email exists, fetch and display the password
        $row = $result->fetch_assoc();
        $message = "Your password: " . $row["password"];
    } else {
        // Email does not exist
        $message = "Email not recognized. Please try again.";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Password</title>
    <style>
        body {
            background-image: url(images/motor.jpg);
            background-size: cover; /* Resize the background image to fit within the container */
            background-repeat: no-repeat; /* Prevent the background image from repeating */
            background-position: center; /* Center the background */
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            font-family: Arial, sans-serif;
        }
        .navbar {
            position: absolute; /* Make navbar position absolute */
            top: 0; /* Align navbar to the top */
            left: 0; /* Align navbar to the left */
            background-color: rgb(196, 0, 0); /* Changed navbar color to red */
            overflow: hidden;
            width: 100%; /* Make navbar full width */
            padding: 0px 1px;
        }

        .navbar a {
            float: left;
            display: block;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 8px; /* Adjust padding here */
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }

        .navbar img {
            float: right; /* Float the logo to the right */
            height: 50px; /* Set the height of the logo */
            margin: 2px 5px; /* Add margin for spacing */
        }
        .pass {
            background-color: #4caf50;
            color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
    
        
    </style>
</head>
<body>
<div class="navbar">
        <a href="index.html">Home</a>
        <a href="travels_catalog.php">Destinations</a>
        <a href="about.html">About</a>
        <img src="logo2.png" alt="Travel Logo"> <!-- Insert your travel logo here -->
    </div>
    <div class="pass">
        <div id="message"><?php echo $message; ?></div>
    </div>
</body>
</html>

<script>
    // Retrieve the message from the PHP variable and insert it into the HTML element
    var message = "<?php echo $message; ?>";
    document.getElementById("message").innerHTML = message;
</script>
