<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        body {
            background-image: url(images/motor.jpg);
            background-size: cover; /* Resize the background image to fit within the container */
            background-repeat: no-repeat; /* Prevent the background image from repeating */
            background-position: center; /* Center the background */
            font-family: Arial, sans-serif;
            background-color: #D3D3D3 ;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            font-family: Arial, sans-serif;
        
        }

        h1 {
            color: #333;
        }
        .navbar {
            position: absolute; /* Make navbar position absolute */
            top: 0; /* Align navbar to the top */
            left: 0; /* Align navbar to the left */
            background-color: rgb(196, 0, 0); /* Changed navbar color to red */
            overflow: hidden;
            width: 100%; /* Make navbar full width */
            padding: 0px 1px;
        }

        .navbar a {
            float: left;
            display: block;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 8px; /* Adjust padding here */
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }

        .navbar img {
            float: right; /* Float the logo to the right */
            height: 50px; /* Set the height of the logo */
            margin: 2px 5px; /* Add margin for spacing */
        }
   
        .forms-container {
           display: flex;
           flex-direction: column; /* Change to column */
           align-items: center; /* Center horizontally */
           width: 100%;
           max-width: 800px;
           margin-bottom: 20px;
        }

        form {
          background-color: #fff;
          padding: 20px;
          border-radius: 8px;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
          width: 100%; /* Change to full width */
          max-width: 400px; /* Set a max-width */
        }

  

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
        }

        input, select {
            width: calc(100% - 16px); /* Adjust width */
            padding: 6px; /* Adjusted padding */
            margin-bottom: 6px; /* Adjusted margin */
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        button {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 6px 10px;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #d32f2f;
        }
    </style>
</head>
<body>
<div class="navbar">
        <a href="index.html">Home</a>
        <a href="travels_catalog.php">Destinations</a>
        <a href="about.html">About</a>
        <img src="logo2.png" alt="Travel Logo"> <!-- Insert your travel logo here -->
    </div>

    <h1>Welcome, Admin!</h1>
    <div class="forms-container">
        <form action="add_travel.php" method="post">
            <input type="submit" value="Add Ticket">
        </form>
    </div>

    <form action="" method="post">
        <h2>Reserved Tickets Information</h2>
        <label for="start_date">Start Date:</label>
        <input type="date" id="start_date" name="start_date" required>
        <label for="end_date">End Date:</label>
        <input type="date" id="end_date" name="end_date" required>
        <input type="submit" value="Search">
    </form>

    <?php
   include("config.php");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $startDate = $_POST["start_date"];
        $endDate = $_POST["end_date"];
        $rentedCarsQuery = "SELECT r.*, c.name AS travel_name, c.destination AS travel_destination, c.travell_id, o.location AS office_location
                            FROM reservation r
                            JOIN travels c ON r.travel_id = c.travel_id
                            JOIN office o ON r.offi_id = o.offi_id
                            WHERE r.start_date >= '$startDate' AND r.end_date <= '$endDate'";
        $rentedCarsResult = $conn->query($rentedCarsQuery);

        if ($rentedCarsResult->num_rows > 0) {
            echo "<table>
                    <tr>
                        <th>Email</th>
                        <th>travel Name</th>
                        <th> Destination</th>
                        <th>travel ID</th>
                        <th>Office Location</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Total Price</th>
                        <th>Action</th>
                    </tr>";

            $totalPrice = 0;

            while ($row = $rentedCarsResult->fetch_assoc()) {
                $totalPrice += $row['amount'];

                echo "<tr>
                        <td>" . $row['cus_id'] . "</td>
                        <td>" . $row['travel_name'] . "</td>
                        <td>" . $row['travel_destination'] . "</td>
                        <td>" . $row['travell_id'] . "</td>
                        <td>" . $row['office_location'] . "</td>
                        <td>" . $row['start_date'] . "</td>
                        <td>" . $row['end_date'] . "</td>
                        <td>" . $row['amount'] . "</td>
                        <td><button onclick='deleteReservation(" . $row['res_id'] . ", " . $row['travel_id'] . ")'>Delete</button></td>
                    </tr>";
            }

            echo "</table>";
            echo "<div id='total-price'>Total Price: $" . $totalPrice . "</div>";
        } else {
            echo "<p>No rented cars information available for the specified date range.</p>";
        }
    }
    ?>



    <a href="logout.php">Logout</a>

</body>
</html>
